/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

import java.io.Serializable;

/**
 *
 * @author Estudiante
 */
public class Auto implements Serializable{
    private String placa;
    private int modelo;
    private String marca;
    private String propietario;

    public Auto() {
    }

    public Auto(String placa, int modelo, String marca, String propietario) throws PlacaException{
        this.placa = placa;
        
        if(placa.length() != 6){
            throw new PlacaException("Placa invalida ! \nDebe tener seis caracteres");
        }
        
        this.modelo = modelo;
        this.marca = marca;
        this.propietario = propietario;
    }
    //QUE EL AUTO TENGA PLACAS XXX123
    
    
    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    /**
     * @return the modelo
     */
    public int getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(int modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return the propietario
     */
    public String getPropietario() {
        return propietario;
    }

    /**
     * @param propietario the cliente to set
     */
    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    @Override
    public String toString() {
        return "Auto{" + "placa=" + placa + ", modelo=" + modelo + ", marca=" + marca + ", propietario=" + propietario + '}'+"\n";
    }
    
    
}
