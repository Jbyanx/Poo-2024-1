/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

import java.io.Serializable;
import java.util.LinkedList;

/**
 *
 * @author ESTUDIANTE
 */
public class Concesionario  implements Serializable{
    private LinkedList<Auto> autos;
    
    public Concesionario(){
        autos = new LinkedList<>();
    }
    
    public void addAuto(Auto a){
        autos.add(a);
    }

    @Override
    public String toString() {
        return "Concesionario{" + "autos=" + autos + '}';
    }
    
    
}
