/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

/**
 *
 * @author Estudiante
 */
public class Materia {
    private int codigo;
    private String nombre;
    private int corte1;
    private int corte2;
    private int corte3;

    public Materia() {
    }

    public Materia(int codigo, String nombre, int corte1, int corte2, int corte3) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.corte1 = corte1;
        this.corte2 = corte2;
        this.corte3 = corte3;
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the corte1
     */
    public int getCorte1() {
        return corte1;
    }

    /**
     * @param corte1 the corte1 to set
     */
    public void setCorte1(int corte1) {
        this.corte1 = corte1;
    }

    /**
     * @return the corte2
     */
    public int getCorte2() {
        return corte2;
    }

    /**
     * @param corte2 the corte2 to set
     */
    public void setCorte2(int corte2) {
        this.corte2 = corte2;
    }

    /**
     * @return the corte3
     */
    public int getCorte3() {
        return corte3;
    }

    /**
     * @param corte3 the corte3 to set
     */
    public void setCorte3(int corte3) {
        this.corte3 = corte3;
    }


    @Override
    public String toString() {
        return "Materia{" + "codigo=" + codigo + ", nombre=" + nombre + ", corte1=" + corte1 + ", corte2=" + corte2 + ", corte3=" + corte3 + " definitiva:" + definitiva();
    }
    
    public int definitiva(){
        return corte1 + corte2 + corte3; 
    }
    
    public boolean aprobada(){
        return(definitiva()>=300);
    }
}
