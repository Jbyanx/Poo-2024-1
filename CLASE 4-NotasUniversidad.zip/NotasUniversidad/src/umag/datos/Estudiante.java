/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

import java.util.Arrays;

/**
 *
 * @author Estudiante
 */
public class Estudiante {

    private int codigo;
    private String nombre;
    private Materia materias[] = new Materia[1000];
    private int nMateria;

    public void addMateria(Materia mat) {
        materias[nMateria++] = mat;
    }

    public Estudiante() {
    }

    public Estudiante(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    /**
     * Obtener una materia por su codigo
     *
     * @param codigo
     * @return Materia si la encuentra o null si no la encuentra
     */
    public Materia getMateria(int codigo) {
        Materia m = new Materia();

        for (Materia materia : materias) {
            if (materia != null) {
                if (materia.getCodigo() == codigo) {
                    m = materia;
                    break;
                }
            }
        }
        return m;
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Estudiante{" + "codigo=" + codigo + ", nombre=" + nombre + ", materias=" + mostrarMaterias() + ", nMateria=" + nMateria + '}';
    }

    private String mostrarMaterias() {
        String lis = "";
        for (int i = 0; i < nMateria; i++) {
            lis += materias[i].toString() + "\n";
        }
        return lis;
    }

}
