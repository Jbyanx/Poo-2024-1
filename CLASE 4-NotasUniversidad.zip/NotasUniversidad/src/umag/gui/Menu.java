/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.gui;

import javax.swing.JOptionPane;
import umag.datos.Estudiante;
import umag.datos.Materia;

/**
 *
 * @author Estudiante
 */
public class Menu {
    
    public static void main(String[] args) {
        menu();
    }

    private static void menu() {
        String men = "\n1.Agregar materia \n2.Listar \n3.buscar Por Codigo \n0.Salir";
        Estudiante estudiante = new Estudiante(10015, "Pedro");
        int op = -1;
        
        do{
            
            op = Integer.parseInt(JOptionPane.showInputDialog(men));
            
            switch (op) {
                case 0:
                    JOptionPane.showMessageDialog(null, "¡Adios!");
                    break;
                case 1:
                    estudiante.addMateria(agregarMateria());
                    JOptionPane.showMessageDialog(null, "¡Materia Agregada exitosamente!");
                    break;
                case 2:
                    listarMaterias(estudiante);
                    break;
                case 3:
                    Materia m = buscarMateria(estudiante);
                    if(m.getNombre()!=null)
                        JOptionPane.showMessageDialog(null, m.toString());
                    else
                        JOptionPane.showMessageDialog(null, "Materia no encontrada");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Digite una opcion valida");
            }
            
        } while(op != 0);
    }

    private static Materia agregarMateria() {
        Materia m;
        
        int codigo = Integer.parseInt(JOptionPane.showInputDialog("Digite el codigo de la materia"));
        String nombre = JOptionPane.showInputDialog("Digite el nombre de la materia");
        int corte1 = Integer.parseInt(JOptionPane.showInputDialog("Digite la nota del primer corte"));
        int corte2 = Integer.parseInt(JOptionPane.showInputDialog("Digite la nota del segundo corte"));
        int corte3 = Integer.parseInt(JOptionPane.showInputDialog("Digite la nota del tercer corte"));
        
        return new Materia(codigo, nombre, corte1, corte2, corte3);
    }
    
    private static void listarMaterias(Estudiante estudiante) {
        JOptionPane.showMessageDialog(null, estudiante.toString());
    }

    private static Materia buscarMateria(Estudiante estudiante) {
        int codigo = Integer.parseInt(JOptionPane.showInputDialog("Codigo de materia a buscar"));
        
        return estudiante.getMateria(codigo);
    }
}
