/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

/**
 *
 * @author ESTUDIANTE
 */
public abstract class Cuenta {
    private int id;
    private String tipo;
    protected float saldo;
    private Cliente cliente;

    
    public abstract float intereses();
    
    public abstract void retirar(float dinero);
    
    public Cuenta(int id, String tipo, Cliente cliente) {
        this.id = id;
        this.tipo = tipo;
        this.cliente = cliente;
        this.saldo = 0;
    }

    
    
    public Cuenta(int id, String tipo, float saldo, Cliente cliente) {
        this.id = id;
        this.tipo = tipo;
        this.saldo = saldo;
        this.cliente = cliente;
    }

    public void consignar(float dinero){
        this.saldo+=dinero;
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the saldo
     */
    public float getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    /**
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    @Override
    public String toString() {
        return "Cuenta{" + "id=" + id + ", tipo=" + tipo + ", saldo=" + saldo + ", cliente=" + cliente + '}';
    }
    
    
}
