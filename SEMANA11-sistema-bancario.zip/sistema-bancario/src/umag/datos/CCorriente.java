/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

/**
 *
 * @author ESTUDIANTE
 */
public class CCorriente extends Cuenta {
    private float sobreGiro;

    public CCorriente(int id, String tipo, Cliente cliente) {
        super(id, tipo, cliente);
    }

    public CCorriente(int id, String tipo, float saldo, Cliente cliente) {
        super(id, tipo, saldo, cliente);
    }

    @Override
    public float intereses() {
        return (float)2/100 * saldo;
    }

    @Override
    public void retirar(float dinero) {
        saldo -= dinero;
        if(saldo<0){
            sobreGiro= saldo*-1;
        }
    }

    @Override
    public void consignar(float dinero) {
        sobreGiro -= dinero;
        
        super.consignar(dinero);
        if(saldo>=0){
            sobreGiro=0;
        }
    }

    
    /**
     * @return the sobreGiro
     */
    public float getSobreGiro() {
        return sobreGiro;
    }

    /**
     * @param sobreGiro the sobreGiro to set
     */
    public void setSobreGiro(float sobreGiro) {
        this.sobreGiro = sobreGiro;
    }
    
}
