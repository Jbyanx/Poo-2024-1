/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

import java.util.ArrayList;

/**
 *
 * @author ESTUDIANTE
 */
public class CAhorros extends Cuenta {
    private ArrayList<Cliente> clientesAdicionales;
    
    public CAhorros(int id, String tipo, float saldo, Cliente cliente) {
        super(id, tipo, saldo, cliente);
    }

    public CAhorros(ArrayList<Cliente> clientesAdicionales, int id, String tipo, Cliente cliente) {
        super(id, tipo, cliente);
        this.clientesAdicionales = clientesAdicionales;
    }

    public CAhorros(ArrayList<Cliente> clientesAdicionales, int id, String tipo, float saldo, Cliente cliente) {
        super(id, tipo, saldo, cliente);
        this.clientesAdicionales = clientesAdicionales;
    }

    @Override
    public float intereses() {
        return (float) 0.11 * saldo;
    }

    @Override
    public void retirar(float dinero) {
        if(saldo-dinero >= 50000) //quedan minimo 50k en la cuenta
            saldo-=dinero;
        else
            System.err.println("Debe dejar $50.000 minimo en la cuenta");
    }

    /**
     * @return the clientesAdicionales
     */
    public ArrayList<Cliente> getClientesAdicionales() {
        return clientesAdicionales;
    }

    /**
     * @param clientesAdicionales the clientesAdicionales to set
     */
    public void setClientesAdicionales(ArrayList<Cliente> clientesAdicionales) {
        this.clientesAdicionales = clientesAdicionales;
    }
    
}
