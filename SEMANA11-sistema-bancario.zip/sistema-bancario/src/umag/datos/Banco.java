/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

import java.util.ArrayList;

/**
 *
 * @author ESTUDIANTE
 */
public class Banco {
    private String nombre;
    private ArrayList<Cuenta> cuentas;
    private ArrayList<Cliente> clientes;

    public Banco(String nombre) {
        this.nombre = nombre;
        cuentas = new ArrayList<>();
        clientes = new ArrayList<>();
    }
    
    public void agregarCuenta(Cuenta cuenta){
        cuentas.add(cuenta);
    }
    
    public void agregarCliente(Cliente cliente){
        clientes.add(cliente);
    }

    /***
     * Total dinero en poder del banco
     */
    public float totalDineroEnBanco(){
        int sum = 0;
        for (Cuenta cuenta : cuentas) {
            sum += cuenta.getSaldo();
        }
        return sum;
    }

    /***
     * Total dinero en poder del banco
     */
    public float totalDineroAPagarIntereses(){
        int sum = 0;
        for (Cuenta cuenta : cuentas) {
            sum += cuenta.intereses();
        }
        return sum;
    }

    /***
     * Total dinero en poder del banco
     */
    public String empresasConCuentaCorriente(){
        String lis = "";
        for (Cliente cliente : clientes) {
            if(cliente.getClass().getSimpleName().equals("CEmpresa")){
                lis+=cliente.getNombre()+"\n";
            }
        }
        return lis;
    }
    
    /***
     * Consignar
     */
    public void consignar(int idCuenta, float dinero){
        Cuenta cuenta = buscarCuenta(idCuenta);
        if(cuenta != null){
            cuenta.consignar(dinero);
        }
    }
    
    public void retirar(int idCuenta, float dinero){
        Cuenta cuenta = buscarCuenta(idCuenta);
        if(cuenta != null){
            cuenta.retirar(dinero);
        }
    }
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the cuentas
     */
    public ArrayList<Cuenta> getCuentas() {
        return cuentas;
    }

    /**
     * @param cuentas the cuentas to set
     */
    public void setCuentas(ArrayList<Cuenta> cuentas) {
        this.cuentas = cuentas;
    }

    /**
     * @return the clientes
     */
    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    /**
     * @param clientes the clientes to set
     */
    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    private Cuenta buscarCuenta(int idCuenta) {
        for (Cuenta cuenta : cuentas) {
            if(cuenta.getId()==idCuenta){
                return cuenta;
            }
        }
        return null;
    }
    
    
    
}
