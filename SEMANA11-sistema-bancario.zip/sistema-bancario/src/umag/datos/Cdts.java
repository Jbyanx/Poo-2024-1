/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

/**
 *
 * @author ESTUDIANTE
 */
public class Cdts extends Cuenta {

    public Cdts(int id, String tipo, Cliente cliente) {
        super(id, tipo, cliente);
    }

    public Cdts(int id, String tipo, float saldo, Cliente cliente) {
        super(id, tipo, saldo, cliente);
    }
    
    @Override
    public float intereses() {
        return (float) 0.2 * saldo;
    }

    @Override
    public void retirar(float dinero) {
        System.err.println("Este tipo de cuenta no permite retirar");
    }
    
    
}
