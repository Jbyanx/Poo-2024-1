/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import umag.datos.Banco;
import umag.datos.CAhorros;
import umag.datos.Cdts;
import umag.datos.Cliente;

/**
 *
 * @author ESTUDIANTE
 */
public class prueba {
    public static void main(String[] args) {
        Banco b = new Banco("bancolombia");
        
        b.agregarCuenta(new CAhorros(001, "Ahorros", 100000, new Cliente("juan perez", 3114578)));
    }
}
