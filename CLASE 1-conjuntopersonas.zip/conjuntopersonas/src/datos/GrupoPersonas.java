package datos;

import javax.swing.JOptionPane;

public class GrupoPersonas {
    
    public static void main(String[] args) {
        //String nombres[] = new String[100];
        //int edades[] = new int[100];
        
        String[] nombres = {"Ana", "Carlos", "María", "Pedro", "Julia", "Juan", "Sofía", "Roberto", "Camila", "Laura"};
        int[] edades = {42, 28, 55, 19, 72, 31, 8, 67, 23, 68};
        int n = 10;
        
        //int n = Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad de personas"));
        
        //capturar datos
        //capturaDatos(nombres, edades, n);
        
        //mostrar todas las personas
        //String listadoPersonas = mostrarDatos(nombres, edades, n);
        //System.out.println("Listado de ersonas-----------------");
        //System.out.println(listadoPersonas);
        
        //mostrar mayores de edad
        //String listadoMayoresEdad = mostrarMayoresEdad(nombres, edades, n);
        //System.out.println("Mayores de edad--------------------");
        //System.out.println(listadoMayoresEdad);
        
        //buscar persona por nombre
        //String nombre = JOptionPane.showInputDialog("Digite el nombre a buscar");
        //String buscarNombre = buscarXNombre(nombres, edades, n, nombre);
        //System.out.println("Buscar por nombre: "+ buscarNombre);
        
        //promedio de edades
        //float promedioEdades = promedioEdades(nombres, edades, n);
        //System.out.println("Promedio de edades: "+promedioEdades);
        
        
        //% de personas de la tercera edad (60 años)
        float porcentajeAncianos = porcentajeTerceraEdad(nombres, edades, n);
        System.out.println("Porcentaje de personas mayoes a 60 anhos: "+porcentajeAncianos);
        
    }

    private static void capturaDatos(String[] nombres, int[] edades, int n) {

        for (int i = 0; i < n; i++) {
            nombres[i] = JOptionPane.showInputDialog("Digitar nombre de la persona numero " + (i + 1));
            edades[i] = Integer.parseInt(JOptionPane.showInputDialog("Digitar edad de la persona numero " + (i + 1)));
        }
    }

    private static String mostrarDatos(String[] nombres, int[] edades, int n) {
        String res = "";
        for (int i = 0; i < n; i++) {
            res += "Persona " + (i + 1) + " Nombre: " + nombres[i] + " Edad: " + edades[i] + "\n";
        }
        return res;
    }

    private static String mostrarMayoresEdad(String[] nombres, int[] edades, int n) {
        String lis = "";
        for (int i = 0; i < n; i++) {
            if (edades[i] >= 18) {
                lis += "Persona " + (i+1) + " Nombre: " + nombres[i] + " Edad: " + edades[i] + "\n";
            }
        }
        return lis;
    }

    private static String buscarXNombre(String[] nombres, int[] edades, int n, String nombre) {
        String persona = "";
        for (int i = 0; i < n; i++) {
            if(nombres[i].equalsIgnoreCase(nombre.trim())){
                JOptionPane.showMessageDialog(null, nombre + " Encontrado!!");
                return "Nombre " + nombres[i] + " Edad " + edades[i];
            }
        }
        return "No encontrado";
    }

    private static float promedioEdades(String[] nombres, int[] edades, int n) {
        int sumEdades = 0;
        int numPersonas = n;
        
        for (int i = 0; i < n; i++) {
            sumEdades += edades[i];
        }
        
        return sumEdades / numPersonas;
    }

    private static float porcentajeTerceraEdad(String[] nombres, int[] edades, int n) {
        int totalPersonas = n;
        int terceraEdad = 0;
        
        for (int i = 0; i < n; i++) {
            if(edades[i] >= 60){
                terceraEdad = terceraEdad + 1;
            }
        }
    
        return (terceraEdad / totalPersonas) * 100;
    }
    

}
