
package datos;

import javax.swing.JOptionPane;

public class TiendaCelulares {
    public static void main(String[] args) {
        Celular celulares[] = new Celular[1000];
        
        //lenar celulares forzados
                
        int n = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de celulares a ingresar"));
        
        capturaDatos(celulares, n);
        
        //% de celulares marca samsung
        String marca = "samsung";
        float porcentaje = porcentajeCelularesXMarca(celulares, n, marca);
        JOptionPane.showMessageDialog(null, "Celulares "+marca+":"+porcentaje+"%");
        
        //listado de telefonos rojos
        String color = "rojo";
        String lis = listarCelularesXColor(celulares, n, color);
        JOptionPane.showMessageDialog(null, "Celulares de color"+color+":\n"+lis);
                
        
        
        //listar Todos
        //hallar celular mas caro
        //listado de celulares que superan el promedio
        //dado un celular borrarlo
    }

    private static void capturaDatos(Celular[] celulares, int n) {
        for (int i = 0; i < n; i++) {
            celulares[i] = new Celular();
            celulares[i].codigo = Integer.parseInt(JOptionPane.showInputDialog("Digite el codigo del celular"));
            celulares[i].marca = JOptionPane.showInputDialog("Digite la marca del celular");
            celulares[i].precio = Float.parseFloat(JOptionPane.showInputDialog("Digite el precio $ del celular"));
            celulares[i].color = JOptionPane.showInputDialog("Digite el color del celular");            
        }
    }

    private static float porcentajeCelularesXMarca(Celular[] celulares, int n, String marca) {
        int cont = 0;
        int total = n;
        
        for (int i = 0; i < n; i++) {
            if(celulares[i].marca.equalsIgnoreCase(marca)){
                cont++;
            }
        }
        
        return (float) cont / n*100;
    }

    private static String listarCelularesXColor(Celular[] celulares, int n, String color) {
        String lis =  "";
        for (int i = 0; i < n; i++) {
            if(celulares[i].color.equalsIgnoreCase(color)){
                lis+= "codigo: "+celulares[i].codigo+ " marca: "+celulares[i].marca+ " precio: "+celulares[i].precio;
            }
        }
        return lis;
    }
}
