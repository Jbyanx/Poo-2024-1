
package datos;

public class Celular {
    public int codigo;
    public String marca;
    public float precio;
    public String color;

    public Celular(){
        
    }
    
    public Celular(int codigo, String marca, float precio, String color) {
        this.codigo = codigo;
        this.marca = marca;
        this.precio = precio;
        this.color = color;
    }
    
    
}
