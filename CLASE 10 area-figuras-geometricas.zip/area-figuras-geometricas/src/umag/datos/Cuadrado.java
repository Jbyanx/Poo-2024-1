/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

/**
 *
 * @author Estudiante
 */
public class Cuadrado extends Figura{
    private int lado;

    public Cuadrado(int lado) {
        this.lado = lado;
    }

    public Cuadrado(int lado, String tipo) {
        super(tipo);
        this.lado = lado;
    }

    @Override
    public void calPerimetro() {
        super.perimetro = 4*lado;
    }

    @Override
    public void calArea() {
        super.area = lado*lado;
    }
    
    /**
     * @return the lado
     */
    public int getLado() {
        return lado;
    }

    /**
     * @param lado the lado to set
     */
    public void setLado(int lado) {
        this.lado = lado;
    }

    @Override
    public String toString() {
        return super.toString()+ " Cuadrado{" + "lado=" + lado + '}';
    }
    
    
}
