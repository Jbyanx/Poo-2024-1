/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

/**
 *
 * @author Estudiante
 */
public class Figura {
    private String tipo;
    protected float area;
    protected float perimetro;

    public Figura() {
    }

    
    public Figura(String tipo) {
        this.tipo = tipo;
    }
    
    public void calArea(){
        
    }
    
    public void calPerimetro(){
        
    }
    
    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the area
     */
    public float getArea() {
        return area;
    }

    /**
     * @param area the area to set
     */
    public void setArea(float area) {
        this.area = area;
        Object ob = new Object();
        ob.toString();
    }

    /**
     * @return the perimetro
     */
    public float getPerimetro() {
        return perimetro;
    }

    /**
     * @param perimetro the perimetro to set
     */
    public void setPerimetro(float perimetro) {
        this.perimetro = perimetro;
    }

    @Override
    public String toString() {
        return "Figura{" + "tipo=" + tipo + ", area=" + area + ", perimetro=" + perimetro + '}';
    }
    
    
}
