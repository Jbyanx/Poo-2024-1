/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

/**
 *
 * @author Estudiante
 */
public class Circulo extends Figura {
    private float radio;

    @Override
    public void calPerimetro() {
        super.perimetro = (float) (2*Math.PI*radio);
    }

    @Override
    public void calArea() {
        super.area = (float) Math.pow((Math.PI* radio),2);
    }

    
    
    public Circulo(float radio) {
        this.radio = radio;
    }

    public Circulo(float radio, String tipo) {
        super(tipo);
        this.radio = radio;
    }

    /**
     * @return the radio
     */
    public float getRadio() {
        return radio;
    }

    /**
     * @param radio the radio to set
     */
    public void setRadio(float radio) {
        this.radio = radio;
    }

    @Override
    public String toString() {
        return super.toString()+ " Circulo{" + "radio=" + radio + '}';
    }
    
    
}
