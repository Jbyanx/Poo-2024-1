/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

/**
 *
 * @author Estudiante
 */
public class Triangulo extends Figura{
    private int base;
    private int altura;

    
    /***
     * Perimetro del triangulo
     */
    @Override
    public void calPerimetro() {
        super.perimetro = base *3;
    }

    /***
     * area del triangulo
     */
    @Override
    public void calArea() {
        super.area = (float)(base*altura)/ 2;
    }

    
    
    public Triangulo(int base, int altura) {
        this.base = base;
        this.altura = altura;
    }

    public Triangulo(int base, int altura, String tipo) {
        super(tipo);
        this.base = base;
        this.altura = altura;
    }

    /**
     * @return the base
     */
    public int getBase() {
        return base;
    }

    /**
     * @param base the base to set
     */
    public void setBase(int base) {
        this.base = base;
    }

    /**
     * @return the altura
     */
    public int getAltura() {
        return altura;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(int altura) {
        this.altura = altura;
    }

    @Override
    public String toString() {
        return super.toString() +" Triangulo{" + "base=" + base + ", altura=" + altura + '}';
    }
    
    
}
