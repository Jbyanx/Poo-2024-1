/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testing;

import umag.datos.Circulo;
import umag.datos.Cuadrado;
import umag.datos.Figura;
import umag.datos.Triangulo;

/**
 *
 * @author Estudiante
 */
public class Prueba {
    public static void main(String[] args) {
        Cuadrado cuadrado = new Cuadrado(10, "CUADRADO");
        calculos(cuadrado);
        
        Triangulo triangulo = new Triangulo(5, 7, "TRIANGULO");
        calculos(triangulo);
        
        Circulo circulo = new Circulo(4, "CIRCULO");
        calculos(circulo);
    }

    private static void calculos(Figura fig) {
        fig.calArea();
        fig.calPerimetro();
        System.out.println(fig.toString());
    }
}
