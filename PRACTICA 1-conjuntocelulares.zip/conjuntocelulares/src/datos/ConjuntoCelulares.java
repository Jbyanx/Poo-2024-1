/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class ConjuntoCelulares {

    public static void main(String[] args) {
        int codigos[] = new int[100];
        String marcas[] = new String[100];
        float precios[] = new float[100];

        int n = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de celulares a ingresar"));

        pedirDatos(codigos, marcas, precios, n);
        mostrarDatos(codigos, marcas, precios, n);
        mostrarCelularesCaros(codigos, marcas, precios, n);//precio > $1'000.000

        float prom = promedioDePrecios(codigos, marcas, precios, n);

        String cadena = "samsung";
        JOptionPane.showMessageDialog(null, buscarXMarca(codigos, marcas, precios, n, cadena));

        JOptionPane.showMessageDialog(null, mostrarPorPrecios(codigos, marcas, precios, n));//de mayor a menor
    }

    private static void pedirDatos(int[] codigos, String[] marcas, float[] precios, int n) {
        for (int i = 0; i < n; i++) {
            codigos[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite el codigo del " + (i + 1) + " celular"));
            marcas[i] = JOptionPane.showInputDialog("Digite la marca del " + (i + 1) + " celular");
            precios[i] = Float.parseFloat(JOptionPane.showInputDialog("Digite el precio del " + (i + 1) + " celular"));
        }
    }

    private static void mostrarDatos(int[] codigos, String[] marcas, float[] precios, int n) {
        String res = "";

        for (int i = 0; i < n; i++) {
            res += "Codigo: " + codigos[i] + " Marca: " + marcas[i] + " precio: $" + precios[i] + "\n";
        }

        if (res.isBlank()) {
            JOptionPane.showMessageDialog(null, "No hay celulares en el sistema");
        } else {
            JOptionPane.showMessageDialog(null, res);
            System.out.println(res);
        }
    }

    private static void mostrarCelularesCaros(int[] codigos, String[] marcas, float[] precios, int n) {
        String res = "";

        for (int i = 0; i < n; i++) {
            if (precios[i] > 1000000) {
                res += "Codigo: " + codigos[i] + " Marca: " + marcas[i] + " precio: $" + precios[i] + "\n";
            }
        }

        if (res.isBlank()) {
            JOptionPane.showMessageDialog(null, "No hay celulares de mas de $1'000.000");
        } else {
            JOptionPane.showMessageDialog(null, res);
            System.out.println(res);
        }
    }

    private static float promedioDePrecios(int[] codigos, String[] marcas, float[] precios, int n) {
        long sumPrecios = 0;
        int numcelulares = n;

        for (int i = 0; i < n; i++) {
            sumPrecios += precios[i];
        }

        return sumPrecios / numcelulares;
    }

    private static String buscarXMarca(int[] codigos, String[] marcas, float[] precios, int n, String cadena) {
        String celulares = "";
        for (int i = 0; i < n; i++) {
            if (marcas[i].equalsIgnoreCase(cadena.trim())) {
                JOptionPane.showMessageDialog(null, cadena + " Encontrado!!");
                return "Nombre " + marcas[i] + " Edad " + marcas[i] + "\n";
            }
        }
        return "No encontrado";
    }

    private static String mostrarPorPrecios(int[] codigos, String[] marcas, float[] precios, int n) {
        if (precios.length <= 1) return "";

        int pivote = (int) precios[precios.length / 2];
        int i = 0;
        int j = precios.length - 1;

        while (i <= j) {
            while (precios[i] < pivote) {
                i++;
            }

            while (precios[j] > pivote) {
                j--;
            }

            if (i <= j) {
                float temp = precios[i];
                precios[i] = precios[j];
                precios[j] = temp;
                i++;
                j--;
            }
        }

        //mostrarPorPrecios(codigos, marcas, precios, 0, j);
        //mostrarPorPrecios(codigos, marcas, vector, n, i, precios.length -1);
        return "";
    }
    

}
