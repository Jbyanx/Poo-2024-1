/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class ConjuntoCelulares {
    public static void main(String[] args) {
        int codigos[] = new int[100];
        String marcas[] = new String[100];
        float precios[] = new float[100];
        
        int n = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de celulares a ingresar"));
        
        pedirDatos(codigos, marcas, precios, n);
        mostrarDatos(codigos, marcas, precios, n);
        mostrarCelularesCaros(codigos, marcas, precios,n);//precio > $1'000.000
        
        float prom = promedioDePrecios(codigos, marcas, precios, n);
    }

    private static void pedirDatos(int[] codigos, String[] marcas, float[] precios, int n) {
        for(int i = 0; i < n; i++){
            codigos[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite el codigo del "+(i+1)+" celular"));
            marcas[i] = JOptionPane.showInputDialog("Digite la marca del "+(i+1)+" celular");
            precios[i] = Float.parseFloat(JOptionPane.showInputDialog("Digite el precio del "+(i+1)+" celular"));
        }
    }

    private static void mostrarDatos(int[] codigos, String[] marcas, float[] precios, int n) {
        String res = "";
        
        for (int i = 0; i < n; i++) {
            res+= "Codigo: "+codigos[i]+" Marca: "+marcas[i]+" precio: $"+precios[i]+"\n";
        }
        
        if(res.isBlank()){
            JOptionPane.showMessageDialog(null,"No hay celulares en el sistema");
        } else{
            JOptionPane.showMessageDialog(null, res);
            System.out.println(res);
        }
    }

    private static void mostrarCelularesCaros(int[] codigos, String[] marcas, float[] precios, int n) {
        String res = "";
        
        for (int i = 0; i < n; i++) {
            if(precios[i] > 1000000){
                res+= "Codigo: "+codigos[i]+" Marca: "+marcas[i]+" precio: $"+precios[i]+"\n";
            }
        }
        
        if(res.isBlank()){
            JOptionPane.showMessageDialog(null,"No hay celulares de mas de $1'000.000");
        } else{
            JOptionPane.showMessageDialog(null, res);
            System.out.println(res);
        }
    }
    
}
