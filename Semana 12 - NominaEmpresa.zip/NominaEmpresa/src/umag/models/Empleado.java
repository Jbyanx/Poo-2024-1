/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.models;

/**
 *
 * @author Estudiante
 */
public class Empleado {
    private String nombre;
    private float horasTrabajadas;
    private float valorHora;
    private String Ciudad;
    private boolean tieneHijos;
    private String genero;

    public Empleado(String nombre, float horasTrabajadas, float valorHora, String Ciudad, boolean tieneHijos, String genero) {
        this.nombre = nombre;
        this.horasTrabajadas = horasTrabajadas;
        this.valorHora = valorHora;
        this.Ciudad = Ciudad;
        this.tieneHijos = tieneHijos;
        this.genero = genero;
    }

    public Empleado() {
    }

    public float salario(){
        return valorHora*horasTrabajadas;
    }
    
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the horasTrabajadas
     */
    public float getHorasTrabajadas() {
        return horasTrabajadas;
    }

    /**
     * @param horasTrabajadas the horasTrabajadas to set
     */
    public void setHorasTrabajadas(float horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }

    /**
     * @return the valorHora
     */
    public float getValorHora() {
        return valorHora;
    }

    /**
     * @param valorHora the valorHora to set
     */
    public void setValorHora(float valorHora) {
        this.valorHora = valorHora;
    }

    /**
     * @return the Ciudad
     */
    public String getCiudad() {
        return Ciudad;
    }

    /**
     * @param Ciudad the Ciudad to set
     */
    public void setCiudad(String Ciudad) {
        this.Ciudad = Ciudad;
    }

    /**
     * @return the tieneHijos
     */
    public boolean isTieneHijos() {
        return tieneHijos;
    }

    /**
     * @param tieneHijos the tieneHijos to set
     */
    public void setTieneHijos(boolean tieneHijos) {
        this.tieneHijos = tieneHijos;
    }

    /**
     * @return the genero
     */
    public String getGenero() {
        return genero;
    }

    /**
     * @param genero the genero to set
     */
    public void setGenero(String genero) {
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "Empleado{" + "nombre=" + nombre + ", horasTrabajadas=" + horasTrabajadas + ", valorHora=" + valorHora + ", Ciudad=" + Ciudad + ", tieneHijos=" + tieneHijos + ", genero=" + genero + '}';
    }
    
    
}
