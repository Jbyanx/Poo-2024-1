/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.controllers;

import java.util.ArrayList;
import umag.models.Empleado;

/**
 *
 * @author Estudiante
 */
public class EmpleadoController {
    private ArrayList<Empleado> empleados = new ArrayList<>();
    
    /***
     * Agregar un empleado
     * @param e 
     */
    public void addEmpleado(Empleado e){
        empleados.add(e);
    }

    /***
     * Listar todos los empleados
     * @return 
     */
    @Override
    public String toString() {
        String lis = "";
        for (Empleado empleado : empleados) {
            lis+= empleado.toString()+"\n";
        }
        return lis;
    }
    
    
}
