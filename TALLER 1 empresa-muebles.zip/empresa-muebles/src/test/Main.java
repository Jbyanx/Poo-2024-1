/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import entidades.Empresa;
import entidades.Mueble;
import entidades.Vendedor;
import entidades.Venta;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class Main {
    static Empresa empresa = new Empresa(1, "Muebles Santa Marta");
    
    public static void main(String[] args) {
        int op;
        
        do{
            op = Integer.parseInt(JOptionPane.showInputDialog("Bienvenido\n"
                    + "1.Agregar Vendedor\n"//ok
                    + "2.Listar Vendedores\n"//ok
                    + "3.Listar Vendedores por sexo y ciudad\n"//ok
                    + "4.Crear una venta de un vendedor\n"//ok
                    + "5.Hallar el valor de la comision de la venta por Id\n"//ok
                    + "6.Tipo de mueble mas vendido\n"
                    + "7.Comision total de un vendedor\n"
                    + "0.salir"));
            
            switch (op) {
                case 0:
                    JOptionPane.showMessageDialog(null,"¡Adios!");
                    break;
                case 1:
                    agregarVendedor();
                    JOptionPane.showMessageDialog(null,"¡Vendedor agregado!");
                    break;
                case 2:
                    String lisVendedores = listarVendedores();
                    JOptionPane.showMessageDialog(null,"vendedores:\n"+lisVendedores);
                    break;
                case 3:
                    String lisVendedoresSexoCiudad = listarVendedoresSexoCiudad();
                    JOptionPane.showMessageDialog(null,"vendedores:\n"+lisVendedoresSexoCiudad);
                    break;
                case 4:
                    crearVenta();
                    JOptionPane.showMessageDialog(null,"venta realizada");
                    break;
                case 5:
                    double d = comisionVenta();
                    JOptionPane.showMessageDialog(null,"comision venta: "+d);
                    break;
                case 6:
                    String tipo = muebleMasVendido();
                    JOptionPane.showMessageDialog(null,"Tipo de mueble mas vendido: "+tipo);
                    break;
                case 7:
                    String vendedor = JOptionPane.showInputDialog("Digite el nombre del vendedor");
                    double comisionventedor = comisionTotalVendedor(vendedor);
                    JOptionPane.showMessageDialog(null,"comision: "+comisionventedor);
                    break;
                default:
                    JOptionPane.showMessageDialog(null,"¡Opcion invalida!");
            }
            
        }while(op!=0);
    }

    private static void agregarVendedor() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("ingrese el id o cedula del vendedor"));
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del vendedor");
        char sexo = JOptionPane.showInputDialog("Ingrese el sexo del vendedor(m - f)").charAt(0);
        String ciudad = JOptionPane.showInputDialog("Ingrese la ciudad del vendedor");
        
        Vendedor v = new Vendedor(id, nombre, sexo, ciudad);
        
        empresa.agregarVendedor(v);
    }
    
    private static String listarVendedores(){
        String list = "";
        for (Vendedor vendedor : empresa.getVendedores()) {
            list += vendedor.toString()+"\n";
        }
        return list;
    }

    private static String listarVendedoresSexoCiudad() {
        String ciudad = JOptionPane.showInputDialog("ciudad a buscar");
        char sexo = JOptionPane.showInputDialog("sexo a buscar").charAt(0);
        
        return empresa.vendedoresPorSexoYCiudad(sexo, ciudad);
    }

    private static void crearVenta() {
        String nombrevendedor = JOptionPane.showInputDialog("Nombre del vendedor que hace la venta");
        
        int id = Integer.parseInt(JOptionPane.showInputDialog("id del inmueble"));
        String tipo = JOptionPane.showInputDialog("tipo del inmueble");
        double precio = Double.parseDouble(JOptionPane.showInputDialog("precio del inmueble"));
        Mueble mueble = new Mueble(id, tipo, precio);
        
        empresa.crearVenta(nombrevendedor, mueble);
    }

    private static double comisionVenta() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("id de la venta"));
        return empresa.comisionVenta(id);
    }

    private static String muebleMasVendido() {
        return empresa.muebleMasvendido();
    }

    private static double comisionTotalVendedor(String vendedor) {
        return empresa.comisionTotalVendedor(vendedor);
    }
}
