/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class Empresa {
    private int id;
    private String nombre;
    private ArrayList<Vendedor> vendedores;
    private ArrayList<Venta> ventas;
    private ArrayList<Mueble> muebles;

    public void agregarVendedor(Vendedor v){
        vendedores.add(v);
    }
    
    public String vendedoresPorSexoYCiudad(char sexo, String ciudad){
        String res = "";
        for (Vendedor ven : vendedores) {
            if((ven.getSexo()== sexo) && (ven.getCiudad().equals(ciudad))){
                res += ven.toString()+"\n";
            }
        }
        return res;
    }
    
    public Venta crearVenta(String nombreVendedor, Mueble mueble){
        int id = Integer.parseInt(JOptionPane.showInputDialog("id de la venta"));
        
        Venta vt= new Venta(id, mueble);
        ventas.add(vt);
        return vt; 
    }
    
    public double comisionVenta(int id){
        double d = 0;
        for (Venta v : ventas) {
            if(v.getId()==id){
                d = v.comisionVenta();
            }
        }
        return d;
    }
    //--------------------------------------------------------------------------
    public Empresa() {
        datosPrueba();
    }
        
    public Empresa(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.vendedores = new ArrayList<>();
        this.ventas = new ArrayList<>();
        this.muebles = new ArrayList<>();
        datosPrueba();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Vendedor> getVendedores() {
        return vendedores;
    }

    public void setVendedores(ArrayList<Vendedor> vendedores) {
        this.vendedores = vendedores;
    }

    public ArrayList<Venta> getVentas() {
        return ventas;
    }

    public void setVentas(ArrayList<Venta> ventas) {
        this.ventas = ventas;
    }

    public ArrayList<Mueble> getMuebles() {
        return muebles;
    }

    public void setMuebles(ArrayList<Mueble> muebles) {
        this.muebles = muebles;
    }

    @Override
    public String toString() {
        return "Empresa{" + "id=" + id + ", nombre=" + nombre + ", vendedores=" + vendedores + ", ventas=" + ventas + ", muebles=" + muebles + '}';
    }

    public String muebleMasvendido() {
        int cComedor = 0;
        int cSala = 0;
        int cDormitorio = 0;
        
        for (Venta ven : ventas) {
            if(ven.getMueble().getTipo().equals("comedor")) cComedor++;
            if(ven.getMueble().getTipo().equals("sala")) cSala++;
            if(ven.getMueble().getTipo().equals("dormitorio")) cDormitorio++;
        }
        
        if(cComedor > cSala && cComedor > cDormitorio){
            return "Comedor";
        }else if(cSala > cComedor && cSala > cDormitorio){
            return "Sala";
        }else{
            return "Dormitorio";
        }
    }

    public double comisionTotalVendedor(String vendedor) {
        double comision = 0;
        
        for (Venta venta : ventas) {
            if(venta.getVendedor().getNombre().equalsIgnoreCase(vendedor)){
                comision +=venta.comisionVenta();
            }
        }
        if(comision ==0) JOptionPane.showMessageDialog(null,"vendedor no encontrado");
        return comision;
    }

    private void datosPrueba() {
        vendedores.add(new Vendedor(1, "Juan", 'm', "Bogotá"));
        vendedores.add(new Vendedor(2, "María", 'f', "Medellín"));
        vendedores.add(new Vendedor(3, "Carlos", 'm', "Cali"));
        vendedores.add(new Vendedor(4, "Ana", 'f', "Barranquilla"));
        vendedores.add(new Vendedor(5, "Pedro", 'm', "Cartagena"));
        vendedores.add(new Vendedor(6, "Laura", 'f', "Bucaramanga"));
        vendedores.add(new Vendedor(7, "Andrés", 'm', "Pereira"));
        vendedores.add(new Vendedor(8, "Sofía", 'f', "Manizales"));
        vendedores.add(new Vendedor(9, "Diego", 'm', "Santa Marta"));
        vendedores.add(new Vendedor(10, "Valentina", 'f', "Villavicencio"));
        
        muebles.add(new Mueble(1, "sala", 1500.0));
        muebles.add(new Mueble(2, "comedor", 1200.0));
        muebles.add(new Mueble(3, "dormitorio", 800.0));
        muebles.add(new Mueble(4, "sala", 1800.0));
        muebles.add(new Mueble(5, "comedor", 1100.0));
        muebles.add(new Mueble(6, "dormitorio", 750.0));
        muebles.add(new Mueble(7, "sala", 1600.0));
        muebles.add(new Mueble(8, "comedor", 1300.0));
        muebles.add(new Mueble(9, "dormitorio", 850.0));
        muebles.add(new Mueble(10, "sala", 1700.0));
    }
}
