/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author HP
 */
public class Venta {
    private int id;
    private Mueble mueble;
    private Vendedor vendedor;

    
    /***
     * 
     */
    public double comisionVenta(){
        if(this.mueble.getTipo().equalsIgnoreCase("dormitorio")){
            return this.mueble.getPrecio() * 0.97;
        } else if(this.mueble.getTipo().equalsIgnoreCase("salas")){
            return this.mueble.getPrecio() * 0.95;
        } else if(this.mueble.getTipo().equalsIgnoreCase("comedores")){
            return this.mueble.getPrecio() * 0.92;
        }
        return 0;
    }
    
    public Venta() {
    }

    public Venta(int id, Mueble mueble) {
        this.id = id;
        this.mueble = mueble;
    }

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Mueble getMueble() {
        return mueble;
    }

    public void setMueble(Mueble mueble) {
        this.mueble = mueble;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    @Override
    public String toString() {
        return "Venta{" + "id=" + id + ", mueble=" + mueble + ", vendedor=" + vendedor + '}';
    }
    
}
