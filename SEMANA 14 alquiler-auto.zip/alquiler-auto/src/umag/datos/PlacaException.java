/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

/**
 *
 * @author Estudiante
 */
public class PlacaException extends Exception {

    public PlacaException(String mensaje) {
        super(mensaje);
    }
    
}
