/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author ESTUDIANTE
 */
public class Pasaje {
    private int numero;
    private Cliente cliente;
    private Ruta ruta;
    private Date fecha;

    public Pasaje(int numero, Cliente cliente, Ruta ruta) {
        this.numero = numero;
        this.cliente = cliente;
        this.ruta = ruta;
        this.fecha = new Date();
        cliente.setNumPasajes(cliente.getNumPasajes()+1);
    }

    public float costo(){
        if(cliente.promocion()){
            return 0;
        }else{
            float costo = ruta.getCosto();
            
//            Calendar c = Calendar.getInstance();
//            int dia c.get(Calendar.DAY_OF_WEEK);
            
            if(this.fecha.getDay()==2){
                costo = costo * 0.70f;
            }
            return costo;
        }
    }
    
    /**
     * @return the numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the ruta
     */
    public Ruta getRuta() {
        return ruta;
    }

    /**
     * @param ruta the ruta to set
     */
    public void setRuta(Ruta ruta) {
        this.ruta = ruta;
    }

    /**
     * @return the fecha
     */
    public Date getFecha() {
        return fecha;
    }

    /**
     * @param fecha the fecha to set
     */
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Pasaje{" + "numero=" + numero + ", cliente=" + cliente + ", ruta=" + ruta + ", fecha=" + fecha + '}';
    }
    
}
