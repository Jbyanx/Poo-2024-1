/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

import java.util.ArrayList;

/**
 *
 * @author ESTUDIANTE
 */
public class Empresa {
    private String nombre;
    private ArrayList<Cliente> clientes;
    private ArrayList<Pasaje> pasajes;
    private ArrayList<Ruta> rutas;

    public Empresa(String nombre) {
        this.nombre = nombre;
        this.clientes = new ArrayList<>();
        this.pasajes = new ArrayList<>();
        this.rutas = new ArrayList<>();
    }
    
    /***
     * Listar pasajes de un cliente
     * @param cedula cedula del cliente a buscar
     * @return listado de pasajes del cliente
     */
    public String listarPasajes(int cedula){
        String lis = "";
        for (Pasaje pasaje : pasajes) {
            if(pasaje.getCliente().getCedula()==cedula){
                lis += pasaje.toString()+ pasaje.costo() +"\n";
            }
        }
        return lis;
    }
    
    /***
     * Vender un pasaje a un cliente
     * @param num numero del pasaje
     * @param cliente cliente comprador
     * @param ruta datos de ruta del pasaje
     * @return costo del pasaje
     */
    public float venderPasaje(int num, Cliente cliente, Ruta ruta){
        Pasaje pa = new Pasaje(num, cliente, ruta);
        pasajes.add(pa);
        return pa.costo();
    }
    /***
     * Añadir un cliente
     * @param c cliente a guardar
     */
    public void addCliente(Cliente c){
        clientes.add(c);
    }
    
    /***
     * Listar todos los clientes
     * @return String listado de clientes
     */
    public String listarClientes(){
        String lis = "";
        for (int i = 0; i < clientes.size(); i++) {
            Cliente cli = clientes.get(i);
            lis +=cli.toString()+"\n";
        }
        return lis;
    }
    
    /***
     * Listado de clientes hombres mayores de edad
     * @return Arraylist<Cliente> que cumplen la condicion
     */
    public ArrayList<Cliente> hombresMayores(){
        ArrayList<Cliente> aux = new ArrayList<>();
        for (Cliente cliente : this.clientes) {
            if(cliente.getGenero().equalsIgnoreCase("masculino") && cliente.getEdad() >= 18){
                aux.add(cliente);
            }
        }
        return aux;
    }
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the clientes
     */
    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    /**
     * @param clientes the clientes to set
     */
    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    /**
     * @return the pasajeses
     */
    public ArrayList<Pasaje> getPasajeses() {
        return pasajes;
    }

    /**
     * @param pasajeses the pasajeses to set
     */
    public void setPasajeses(ArrayList<Pasaje> pasajeses) {
        this.pasajes = pasajeses;
    }

    /**
     * @return the rutas
     */
    public ArrayList<Ruta> getRutas() {
        return rutas;
    }

    /**
     * @param rutas the rutas to set
     */
    public void setRutas(ArrayList<Ruta> rutas) {
        this.rutas = rutas;
    }
    
    
}
