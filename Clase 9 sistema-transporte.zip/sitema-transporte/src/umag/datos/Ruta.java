
package umag.datos;

/**
 *
 * @author Jabes Borre
 */
public class Ruta {
    private int id;
    private String origen;
    private String destino;
    private float costo;

    public Ruta(int id, String origen, String destino, float costo) {
        this.id = id;
        this.origen = origen;
        this.destino = destino;
        this.costo = costo;
    }

    public Ruta(int id, String destino, float costo) {
        this.id = id;
        this.origen = "Santa marta";
        this.destino = destino;
        this.costo = costo;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    @Override
    public String toString() {
        return "Ruta{" + "id=" + id + ", origen=" + origen + ", destino=" + destino + ", costo=" + costo + '}';
    }
    
    
}
