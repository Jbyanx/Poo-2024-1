/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package datos.util;

/**
 *
 * @author Estudiante
 */
public interface Impuesto {
    
    public float iva();
    public float multa();
    
}
