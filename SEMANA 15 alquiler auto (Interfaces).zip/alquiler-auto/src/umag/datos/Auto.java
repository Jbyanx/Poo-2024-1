/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

import datos.util.Impuesto;
import java.io.Serializable;

/**
 *
 * @author Estudiante
 */
public class Auto implements Serializable, Comparable<Auto>, Impuesto{
    private String placa;
    private int modelo;
    private String marca;
    private String propietario;
    private float costo;

    public Auto() {
    }

    public Auto(String placa, int modelo, String marca, String propietario, float costo) throws PlacaException{
        this.placa = placa;
        
        if(placa.length() != 6){
            throw new PlacaException("Placa invalida ! \nDebe tener seis caracteres");
        }
        
        this.modelo = modelo;
        this.marca = marca;
        this.propietario = propietario;
        this.costo = costo;
    }
    //QUE EL AUTO TENGA PLACAS XXX123

    public Auto(String placa) {
        this.placa = placa;
    }
    
    
    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    /**
     * @return the modelo
     */
    public int getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(int modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return the propietario
     */
    public String getPropietario() {
        return propietario;
    }

    /**
     * @param propietario the cliente to set
     */
    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    @Override
    public float iva() {
        return 0.19f * costo;
    }

    @Override
    public float multa() {
        return 0;
    }

    public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }
    
    /***
     * Comparar Autos
     * @param auto
     * @return < 0 cuando el parametro es mayor = 0 cuando son iguales y > 0 cuando el parametro es menor 
     */
    @Override
    public int compareTo(Auto o) {
        return this.placa.compareTo(o.placa);
    }

    @Override
    public String toString() {
        return "Auto{" + "placa=" + placa + ", modelo=" + modelo + ", marca=" + marca + ", propietario=" + propietario + ", costo=" + costo + '}';
    }

    
}
