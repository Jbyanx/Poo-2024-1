/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.persistencia;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import umag.datos.Concesionario;

/**
 *
 * @author ESTUDIANTE
 */
public class Serializacion {
    
    public void guardar(Concesionario c, String nombreArchivo) throws FileNotFoundException, IOException{
        FileOutputStream file = new FileOutputStream(nombreArchivo);
        ObjectOutputStream objeto = new ObjectOutputStream(file);
        objeto.writeObject(c);//guardando concecionario
        file.close();
        objeto.close();
    }
    
    public Concesionario recuperar(String nombreArchivo) throws FileNotFoundException, IOException, ClassNotFoundException{
        FileInputStream archivo = new FileInputStream(nombreArchivo);
        ObjectInputStream objeto = new ObjectInputStream(archivo);
        Concesionario cons = (Concesionario) objeto.readObject();
        archivo.close();
        objeto.close();
        return cons;
    }
    
}
