/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class ConjuntoResidencial {
    private String nombre;
    private ArrayList<Apartamento> apartamentos = new ArrayList<>();
    private ArrayList<Propietario> propietarios = new ArrayList<>();
    
    /***
     * Agegar un apartamento
     * @param apartamento Objeto Apartamento
     */
    public void addApartamento(Apartamento apartamento){
        apartamentos.add(apartamento);
        JOptionPane.showMessageDialog(null, "Apartamento agregado con exito!");
    }
    
    /***
     * Agregar un propietario
     * @param propietario Objeto Propietario
     */
    public void addPropietario(Propietario propietario){
        propietarios.add(propietario);
        JOptionPane.showMessageDialog(null, "Propietario ingresado con exito!");
    }
    
    public void pagarMesAdministracion(int numApt, int numMes){
        Apartamento apt = buscarApartamento(numApt);
        
        if(apt!=null){
            apt.setDescuento_pronto_pago(numMes);
            float valorPago = apt.totalPagar();
            apt.setPago(true);
            
            JOptionPane.showMessageDialog(null, "Apartamento n°"+ numApt + " pago exitosamente, valor: $"+
                    valorPago);        
            
        }else{
            JOptionPane.showMessageDialog(null, "Numero de apartamento no encontrado");        
        }
    }

    private Apartamento buscarApartamento(int numApt) {
        for (Apartamento apartamento : apartamentos) {
            if(apartamento.getNumero()==numApt){
                return apartamento;
            }
        }
        return null;
    }
    
    public float porcentajeAptosAlquilados(){
        int cont = 0;
        
        for (Apartamento apartamento : apartamentos) {
            if(apartamento.getEstado() == Estado.ALQUILADO){
                cont++;
            }
        }
        return (float)(cont / apartamentos.size())*100;
    }
    
    
    public float porcentajeAptosVacios(){
        int cont = 0;
        
        for (Apartamento apartamento : apartamentos) {
            if(apartamento.getEstado() == Estado.VACIO){
                cont++;
            }
        }
        return (float)(cont / apartamentos.size())*100;
    }
    
    public ArrayList<Apartamento> aptosPorpropietario(int cedula){
        ArrayList<Apartamento> aptos = new ArrayList<>();
        
        for (Apartamento apartamento : apartamentos) {
            if(apartamento.getPropietario().getCedula() == cedula)
                aptos.add(apartamento);
        }
        return aptos;
    }
    
    public float totalDineroAdministracion(){
        float sum = 0;
        for (Apartamento apartamento : apartamentos) {
            sum += apartamento.totalPagar();
        }
        return sum;
    }

    public String listarApartamentos() {
        String lis = "";
        for (Apartamento apartamento : apartamentos) {
            lis += apartamento.toString()+"\n";
        }
        return lis;
    }

    public String listarPropietarios() {
        String lis = "";
        for (Propietario prop : propietarios) {
            lis += prop.toString()+"\n";
        }
        return lis;
    }
}
