/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class Apartamento {
    private int numero;
    private int numeroPiso;
    private float valorBaseAdministracion;
    private float descuento_pronto_pago;
    private Propietario propietario;
    private boolean pago;
    private Estado estado;

    public Apartamento() {
    }

    public Apartamento(int numero, int numeroPiso) {
        this.numero = numero;
        this.numeroPiso = numeroPiso;
        this.setValorBaseAdministracion();
        this.estado = Estado.VACIO;
    }
    /***
     * Crear un Objeto de la clase Apartamento
     * @param numero identificador
     * @param numeroPiso numero del piso
     * @param descuento_pronto_pago
     * @param propietario Propietario del apartamento
     */
    public Apartamento(int numero, int numeroPiso, Propietario propietario) {
        this.numero = numero;
        this.numeroPiso = numeroPiso;
        this.setValorBaseAdministracion();
        this.propietario = propietario;
        this.estado = Estado.VACIO;
    }

    public float totalPagar(){
        return this.valorBaseAdministracion - this.descuento_pronto_pago;
    }
    
    public int getNumero() {
        return numero;
    }

    public void setNumero(int n) {
        this.numero = n;
    }

    public int getNumeroPiso() {
        return numeroPiso;
    }

    public void setNumeroPiso(int numeroPiso) {
        if(this.numeroPiso >= 1 && this.numeroPiso <= 10){
            this.numeroPiso = numeroPiso;
        } else{
            JOptionPane.showMessageDialog(null, "Piso fuera de rango");           
        }
    }

    public float getValorBaseAdministracion() {
        return valorBaseAdministracion;
    }

    public void setValorBaseAdministracion() {
        if(this.numeroPiso == 1){
            this.valorBaseAdministracion = 200000;
        } else if(this.numeroPiso >= 2 && this.numeroPiso <= 9){
            this.valorBaseAdministracion = 240000;
        } else if(this.numeroPiso == 10){
            this.valorBaseAdministracion = 300000;
        }     
    }

    public float getDescuento_pronto_pago() {
        return descuento_pronto_pago;
    }

    public float setDescuento_pronto_pago(int diaMes) {
        if(diaMes <= 10){
            return (float) (this.valorBaseAdministracion * 0.1); 
        }
        return 0;
    }

    public Propietario getPropietario() {
        return propietario;
    }

    public void setPropietario(Propietario propietario) {
        this.propietario = propietario;
    }

    @Override
    public String toString() {
        return "Apartamento{" + "numero=" + numero + ", numeroPiso=" + numeroPiso + ", valorBaseAdministracion=" + valorBaseAdministracion + ", descuento_pronto_pago=" + descuento_pronto_pago + ", propietario=" + propietario + '}';
    }

    public boolean isPago() {
        return pago;
    }

    public void setPago(boolean pago) {
        this.pago = pago;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }
    
}
