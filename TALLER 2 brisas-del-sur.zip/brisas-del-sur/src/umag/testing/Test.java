/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.testing;

import javax.swing.JOptionPane;
import umag.datos.Apartamento;
import umag.datos.ConjuntoResidencial;
import umag.datos.Propietario;

/**
 *
 * @author HP
 */
public class Test {
    public static void main(String[] args) {
        ConjuntoResidencial cr = new ConjuntoResidencial();
       
        int op;
        
        do{
            op = Integer.parseInt(JOptionPane.showInputDialog(null, "Bienvenido\n"
                    + "1.Agregar apartamento\n"
                    + "2.Agregar dueño\n"
                    + "3.Hacer pago de administracion\n"
                    + "4.% de apartamentos alquilados\n"
                    + "5.% de apartamentos vacios\n"
                    + "6.buscar apartamentos de un dueño\n"
                    + "7.dinero total pagado en Administracion\n"
                    + "8.Listar Apartamentos\n"
                    + "9.Listar Propietarios\n"
                    + "0.SALIR"));
            
            switch(op){
                case 0:
                    JOptionPane.showMessageDialog(null, "¡Adios!");
                    break;
                case 1:
                    int numero = Integer.parseInt(JOptionPane.showInputDialog("numero de apartamento"));
                    int piso = Integer.parseInt(JOptionPane.showInputDialog("piso"));
                    
                    int confirmPro = JOptionPane.showConfirmDialog(null, "Apartamento con propietario?");
                    
                    if(confirmPro == JOptionPane.YES_OPTION){
                        int cc = Integer.parseInt(JOptionPane.showInputDialog("cedula del propietario"));
                        String nombre = JOptionPane.showInputDialog("nombre del propietario");
                        
                        Apartamento ap = new Apartamento(numero, piso,new Propietario(cc, nombre));
                        cr.addPropietario(new Propietario(cc, nombre));
                        cr.addApartamento(ap);
                        JOptionPane.showMessageDialog(null, "Apartamento ingresado para "+ nombre);
                    } else if (confirmPro == JOptionPane.NO_OPTION){
                        Apartamento ap = new Apartamento(numero, piso);
                        cr.addApartamento(ap);
                        JOptionPane.showMessageDialog(null, "Apartamento ingresado");
                    }
                    break;
                case 2:
                    int cc = Integer.parseInt(JOptionPane.showInputDialog("cedula del propietario"));
                    String nombre = JOptionPane.showInputDialog("nombre del propietario");
                    
                    cr.addPropietario(new Propietario(cc, nombre));
                    JOptionPane.showMessageDialog(null, "Propietario ingresado ("+ nombre+ ")");
                    break;
                case 3:
                    int numeroApt = Integer.parseInt(JOptionPane.showInputDialog("Numero de apartamento a pagar"));
                    int numMes = Integer.parseInt(JOptionPane.showInputDialog("Numero del dia del mes que realiza el pago"));
                    cr.pagarMesAdministracion(numeroApt, numMes);
                    
                    break;
                case 4:
                    float aptosAlq = cr.porcentajeAptosAlquilados();
                    JOptionPane.showMessageDialog(null, "Apartamentos alquilados "+aptosAlq+"%");
                    break;
                case 5:
                    float aptosVac = cr.porcentajeAptosVacios();
                    JOptionPane.showMessageDialog(null, "Apartamentos vacios "+aptosVac+"%");
                    break;
                case 6:
                    int ceula = Integer.parseInt(JOptionPane.showInputDialog("Cedula del propietario"));
                    JOptionPane.showMessageDialog(null, "Lista de aptos\n"+ cr.aptosPorpropietario(ceula).toString());
                    break;
                case 7:
                    float cantidad = cr.totalDineroAdministracion();
                    JOptionPane.showMessageDialog(null, "$"+cantidad);
                    break;
                case 8:
                    String lisAptos = cr.listarApartamentos();
                    JOptionPane.showMessageDialog(null, "Apartamentos:\n"+lisAptos);
                    break;
                case 9:
                    String lisProp = cr.listarPropietarios();
                    JOptionPane.showMessageDialog(null, "Propietarios:\n"+lisProp);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opcion invalida");
                    break;
            }
        } while (op != 0);
        
        
    }
}
