package test;

import entidades.Cliente;
import entidades.Habitacion;
import entidades.Reservacion;
import hotel.GrupoHabitaciones;

import javax.swing.*;

public class principal {
    static GrupoHabitaciones g = new GrupoHabitaciones();
    static Reservacion reservas[] = new Reservacion[500];
    static int nReservas = 0;

    public static void main(String[] args) {
        menu();
    }

    private static void menu() {
        int op;
        do{
            op = Integer.parseInt(JOptionPane.showInputDialog("Bienvenido\n" +
                    "1.Agregar habitacion\n" +
                    "2.Agregar Cliente\n" +
                    "3.Promedio de edades de los clientes\n" +
                    "4.Reservar Habitacion\n" +
                    "5.Entregar Habitacion\n" +
                    "6.Listado de Habitaciones\n" +
                    "7.Listado de Clientes\n" +
                    "8.Buscar precio de reservacion por codigo de reserva(NO)\n" +
                    "9.porcentaje de habitaciones desocupadas\n" +
                    "0.Salir"));

            switch (op){
                case 0:
                    JOptionPane.showMessageDialog(null, "Adios");
                    break;
                case 1:
                    Habitacion h;

                    int codigoHabitacion = Integer.parseInt(JOptionPane.showInputDialog("Digite el codigo de la habitacion"));
                    boolean estaReservada = false;
                    int iconJacuzzi = JOptionPane.showConfirmDialog(null,"¿Tiene Jacuzzi?");
                    boolean conJacuzzi = iconJacuzzi == JOptionPane.YES_OPTION;
                    String tipo = JOptionPane.showInputDialog("Digite el tipo de habitacion(Individual-Doble)");

                    h = new Habitacion(codigoHabitacion,estaReservada,conJacuzzi,tipo);
                    g.agregarHabitacion(h);
                    break;

                case 2:
                    Cliente c;
                    int codigoCliente = Integer.parseInt(JOptionPane.showInputDialog("Digite el cod del cliente"));
                    String nombre = JOptionPane.showInputDialog("Digite el nombre del cliente");
                    String membresia = JOptionPane.showInputDialog("Membresia del cliente(oro-plata-sin membresia)");
                    int edad = Integer.parseInt(JOptionPane.showInputDialog("Digite la edad del cliente"));

                    c = new Cliente(codigoCliente,nombre, membresia,edad);
                    g.agregarCliente(c);
                    break;

                case 3:
                    float promEdades = g.promedioEdadesClientes();
                    JOptionPane.showMessageDialog(null,"El promedio de edades de los clientes es:\n" +promEdades+" años");
                    break;

                case 4:
                    int indiceHab = Integer.parseInt(JOptionPane.showInputDialog("indice de habitacion a reservar"));
                    String cli = JOptionPane.showInputDialog("nombre de cliente que reserva");
                    String codigoReserva = JOptionPane.showInputDialog("codigo de la reserva");

                    //obtiene la habitacion y el cliente
                    Habitacion hab4 = g.getHabitaciones()[indiceHab];
                    Cliente cli4 = g.buscarCliente(cli);
                    //hace la reserva
                    Reservacion re = new Reservacion(codigoReserva, cli4, hab4);

                    re.reservarHabitacion();
                    reservas[nReservas++] = re;
                    break;

                case 5:
                    int indHab = Integer.parseInt(JOptionPane.showInputDialog("indice de habitacion a entregar"));

                    Habitacion hab5 = g.getHabitaciones()[indHab];
                    hab5.entregarHabitacion();
                    nReservas--;
                    break;

                case 6:
                    String lisHabitaciones = g.mostrarHabitaciones();
                    JOptionPane.showMessageDialog(null,"Listado de habitaciones:\n" +lisHabitaciones);
                    break;
                case 7:
                    String lisClientes = g.mostrarClientes();
                    JOptionPane.showMessageDialog(null,"Listado de clientes:\n" +lisClientes);
                    break;
                case 8:
                    String codRes = JOptionPane.showInputDialog("Digite el codigo de la reserva");

                    float costo = 0;
                    for (int i = 0; i < nReservas; i++) {
                        if(reservas[i].getCodigo().equalsIgnoreCase(codRes)){
                            costo = reservas[i].obtenerCosto();
                        }
                    }
                    if(costo==0){
                        JOptionPane.showMessageDialog(null,"Codigo no encontrado");
                    } else{
                        JOptionPane.showMessageDialog(null,"La Reserva N°"+codRes+" tiene un valor de: $"+costo);
                    }

                    break;
                case 9:
                    float porHabDes = g.porcentajeHabDesoc();
                    JOptionPane.showMessageDialog(null,"porcentaje de habitaciones desocupadas: "+porHabDes+"%");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "opcion invalida"); break;
            }
        } while(op!=0);
    }

}
