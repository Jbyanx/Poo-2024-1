package hotel;

import entidades.Cliente;
import entidades.Habitacion;

import javax.swing.*;
import java.util.Arrays;

public class GrupoHabitaciones {
    private Habitacion habitaciones[] = new Habitacion[500];
    private Cliente clientes[] = new Cliente[500];
    private int contadorHabitaciones = 0;
    private int contadorClientes = 0;



    public void agregarHabitacion(Habitacion h){
        habitaciones[contadorHabitaciones++] = h;
        JOptionPane.showMessageDialog(null, "Habitacion agregada!");
    }

    public void agregarCliente(Cliente c){
        clientes[contadorClientes++] = c;
        JOptionPane.showMessageDialog(null, "Cliente agregado!");
    }

    public float promedioEdadesClientes(){
        int sum = 0;

        for (int i = 0; i < contadorClientes; i++){
            sum += clientes[i].getEdad();
        }

        float prom = (float) sum / contadorClientes;
        return prom;
    }

    public float porcentajeHabDesoc(){
        float cont = 0;
        for (int i = 0; i < contadorHabitaciones; i++){
            if(!habitaciones[i].isEstaReservada()){
                cont++;
            }
        }
        return (cont / contadorHabitaciones) * 100;
    }
    public String mostrarHabitaciones(){
        String lis="";
        for (int i = 0; i < contadorHabitaciones; i++){
            lis+= habitaciones[i].toString()+" \n";
        }
        return lis;
    }

    public String mostrarClientes(){
        String lis="";
        for (int i = 0; i < contadorClientes; i++){
            lis+= clientes[i].toString()+" \n";
        }
        return lis;
    }

    public Habitacion[] getHabitaciones() {
        return habitaciones;
    }

    public Cliente[] getClientes() {
        return clientes;
    }

    public Cliente buscarCliente(String cli) {
        Cliente c = null;
        for(int i=0; i<contadorClientes; i++){
            if(clientes[i].getNombre().equalsIgnoreCase(cli)){
                c = clientes[i];
            }
        }
        return c;
    }
    @Override
    public String toString() {
        return "GrupoHabitaciones{" +
                "habitaciones=" + Arrays.toString(habitaciones) +
                ", clientes=" + Arrays.toString(clientes) +
                ", contadorHabitaciones=" + contadorHabitaciones +
                ", contadorClientes=" + contadorClientes +
                '}';
    }

}
