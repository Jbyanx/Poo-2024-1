package entidades;

public class Cliente {
    private int codigo;
    private String nombre;
    private String membresia;   //(Sin membresia, Plata, Oro)
    private int edad;
    private float descuento;     //descuento en USD

    public Cliente() {
    }

    public Cliente(int codigo, String nombre, String membresia, int edad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.membresia = membresia.toLowerCase().trim();
        this.edad = edad;

        setDescuento();
    }


    private void setDescuento() {
        if (this.membresia.equalsIgnoreCase("oro")){
            this.descuento = 20;
        } else if (this.membresia.equalsIgnoreCase("plata")) {
            this.descuento = 10;
        } else{
            this.descuento = 0;
        }
    }

    public float getDescuento() {
        return descuento;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMembresia() {
        return membresia;
    }

    public void setMembresia(String membresia) {
        this.membresia = membresia;
        setDescuento();
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Cliente {" +
                "codigo cliente=" + codigo +
                ", nombre='" + nombre + '\'' +
                ", membresia='" + membresia + '\'' +
                ", edad=" + edad +
                '}';
    }
}
