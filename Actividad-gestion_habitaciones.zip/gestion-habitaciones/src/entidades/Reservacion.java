package entidades;

public class Reservacion {
    private String codigo;
    private Cliente cliente;
    private Habitacion habitacion;

    public Reservacion(){

    }
    public Reservacion(String codigo, Cliente cliente, Habitacion habitacion) {
        this.codigo = codigo;
        this.cliente = cliente;
        this.habitacion = habitacion;
    }
    public void reservarHabitacion(){
        habitacion.reservarHabitacion(this.cliente);
    }
    public float obtenerCosto(){
        return habitacion.getPrecioFinal();
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Habitacion getHabitacion() {
        return habitacion;
    }

    public void setHabitacion(Habitacion habitacion) {
        this.habitacion = habitacion;
    }
}
