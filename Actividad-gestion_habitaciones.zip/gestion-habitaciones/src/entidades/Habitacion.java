package entidades;

import javax.swing.*;

public class Habitacion {
    private int codigo;
    private boolean estaReservada;
    private boolean conJacuzzi; //10 USD mas(Ya esta)
    private String tipo;    //Individual - 50 USD  && Doble 90 USD(Ya esta)
    private float precioBase;   //depende del tipo(ya esta)
    private float precioFinal;  //depende de precioBase, jacuzzi, descuento cliente(ya esta)
    private Cliente cliente;

    public Habitacion() {
    }

    public Habitacion(int codigo, boolean estaReservada, boolean conJacuzzi, String tipo) {
        this.codigo = codigo;
        this.estaReservada = estaReservada;
        this.conJacuzzi = conJacuzzi;
        this.tipo = tipo.toLowerCase().trim();
        precioBase();
        calcPrecioFinal();
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public boolean isEstaReservada() {
        return estaReservada;
    }

    public void setEstaReservada(boolean estaReservada) {
        this.estaReservada = estaReservada;
    }

    public boolean isConJacuzzi() {
        return conJacuzzi;
    }

    public void setConJacuzzi(boolean conJacuzzi) {
        this.conJacuzzi = conJacuzzi;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getPrecioBase() {
        return precioBase;
    }

    public float getPrecioFinal() {
        return precioFinal;
    }

    public Cliente getCliente() {
        return cliente;
    }

    private void precioBase() {
        if(this.tipo.equalsIgnoreCase("individual")){
            this.precioBase = 50;
        } else if (this.tipo.equalsIgnoreCase("doble")) {
            this.precioBase = 90;
        }
    }

    public void entregarHabitacion(){
        if(estaReservada){
            this.cliente = null;
            this.estaReservada = false;
            JOptionPane.showMessageDialog(null, "habitacion entregada!  (queda libre para reservar)");
        }else{
            JOptionPane.showMessageDialog(null, "Error, la habitacion ya esta desocupada!");
        }
        calcPrecioFinal();
    }

    public void reservarHabitacion(Cliente c){
        if(!estaReservada){
            this.cliente = c;
            this.estaReservada = true;
            JOptionPane.showMessageDialog(null, "habitacion reservada! por "+ c.getNombre());
        }else{
            JOptionPane.showMessageDialog(null, "Error, habitacion ocupada! por "+ this.cliente.getNombre());
        }
        calcPrecioFinal();
    }

    public float calcPrecioFinal(){
        if(this.cliente==null){
            this.precioFinal = this.precioBase + jacuzzi();
        }else{
            this.precioFinal = this.precioBase + jacuzzi() - cliente.getDescuento();
        }
        return this.precioFinal;
    }

    private float jacuzzi() {
        if(this.conJacuzzi){
            return 10;
        }
        return 0;
    }

    @Override
    public String toString() {
        String res = (this.estaReservada) ? "habitacion reservada" : "no reservada" ;
        String jac = (this.conJacuzzi) ? "Tiene jacuzzi" : "sin jacuzzi";
        String s = "Habitacion { \n codigo habitacion=" + codigo + ", " +res+ ", " +jac +", tipo=" + tipo +
                ", precioBase=" + precioBase + ", precioFinal=" + precioFinal +
                ", cliente=" + cliente +"\n";
        return s;
    }
}
