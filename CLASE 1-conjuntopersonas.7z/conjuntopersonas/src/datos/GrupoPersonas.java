package datos;

import javax.swing.JOptionPane;

public class GrupoPersonas {

    public static void main(String[] args) {
        String nombres[] = new String[100];
        int edades[] = new int[100];
        int n = Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad de personas"));
        
        //capturar datos
        capturaDatos(nombres, edades, n);
        
        //mostrar todas las personas
        String listadoPersonas = mostrarDatos(nombres, edades, n);
        JOptionPane.showMessageDialog(null, listadoPersonas);
        
        //mostrar mayores de edad
        String listadoMayoresEdad = mostrarMayoresEdad(nombres, edades, n);
        JOptionPane.showMessageDialog(null, listadoMayoresEdad);
        
        //buscar persona por nombre
        String nombre = JOptionPane.showInputDialog("Digite el nombre a buscar");
        String buscarNombre = buscarXNombre(nombres, edades, n, nombre);
        JOptionPane.showMessageDialog(null, buscarNombre);

        //promedio de edades
        float promedioEdades = promedioEdades(nombres, edades, n);
        JOptionPane.showMessageDialog(null, "El promedio de edades es: \n"+promedioEdades);
        
        //% de personas de la tercera edad (60 años)
        float porcentajeAncianos = porcentajeTerceraEdad(nombres, edades, n);
        
        /*  -----PROYECTO------
            realice un proyecto para el manejo de un conjunto de celulares(codigo, mnarca, precio)
            5 requerimientos 
         */
    }

    private static void capturaDatos(String[] nombres, int[] edades, int n) {

        for (int i = 0; i < n; i++) {
            nombres[i] = JOptionPane.showInputDialog("Digitar nombre de la persona numero " + (i + 1));
            edades[i] = Integer.parseInt(JOptionPane.showInputDialog("Digitar edad de la persona numero " + (i + 1)));
        }
    }

    private static String mostrarDatos(String[] nombres, int[] edades, int n) {
        String res = "";
        for (int i = 0; i < n; i++) {
            res += "Persona " + (i + 1) + " Nombre: " + nombres[i] + " Edad: " + edades[i] + "\n";
        }
        return res;
    }

    private static String mostrarMayoresEdad(String[] nombres, int[] edades, int n) {
        String lis = "";
        for (int i = 0; i < n; i++) {
            if (edades[i] >= 18) {
                lis += "Persona " + (i++) + " Nombre: " + nombres[i] + " Edad: " + edades[i] + "\n";
            }
        }
        return lis;
    }

    private static String buscarXNombre(String[] nombres, int[] edades, int n, String nombre) {
        String persona = "";
        for (int i = 0; i < n; i++) {
            if(nombres[i].equalsIgnoreCase(nombre.trim())){
                JOptionPane.showMessageDialog(null, nombre + " Encontrado!!");
                return "Nombre " + nombres[i] + " Edad " + edades[i];
            }
        }
        return "No encontrado";
    }

    private static float promedioEdades(String[] nombres, int[] edades, int n) {
        int sumEdades = 0;
        int numPersonas = n;
        
        for (int i = 0; i < n; i++) {
            sumEdades += edades[i];
        }
        
        return sumEdades / numPersonas;
    }

    private static float porcentajeTerceraEdad(String[] nombres, int[] edades, int n) {
        int totalPersonas = n;
        int terceraEdad = 0;
        //ON READY
    }
}
